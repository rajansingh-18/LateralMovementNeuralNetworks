"""Sentinel Graph educational simulation."""
